"""uConsole TUI modules."""
