#!/bin/bash
# Push uConsole system status to the uconsole.cloud API.
# Runs every 5 minutes via cron. Pure bash, no jq/python deps.
# Reads config from ~/.config/uconsole/status.env

set -euo pipefail

# ── Load config ─────────────────────────────────────────
# Parse status.env explicitly instead of `source`-ing it. The file is
# owned and written by uconsole-setup, but it's still rotated through
# user-controlled flows (re-link, manual edits) so treating it as
# executable code would let any future write-path turn it into RCE.
ENV_FILE="${HOME}/.config/uconsole/status.env"
if [ ! -f "$ENV_FILE" ]; then
    echo "Missing $ENV_FILE" >&2
    exit 1
fi

env_value() {
    local key="$1"
    grep -E "^[[:space:]]*${key}=" "$ENV_FILE" 2>/dev/null \
        | tail -n1 \
        | sed -E "s/^[[:space:]]*${key}=//; s/^\"(.*)\"\$/\1/; s/^'(.*)'\$/\1/"
}

DEVICE_API_URL=$(env_value DEVICE_API_URL)
DEVICE_TOKEN=$(env_value DEVICE_TOKEN)
DEVICE_REPO=$(env_value DEVICE_REPO)

: "${DEVICE_API_URL:?}"
: "${DEVICE_TOKEN:?}"
: "${DEVICE_REPO:?}"

# ── Helpers ─────────────────────────────────────────────
read_file() { cat "$1" 2>/dev/null || echo "$2"; }

json_escape() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\r'/}"
    s="${s//$'\t'/\\t}"
    printf '%s' "$s"
}

# ── Battery ─────────────────────────────────────────────
BAT_PATH="/sys/class/power_supply/axp20x-battery"
BAT_CAPACITY=$(read_file "$BAT_PATH/capacity" "0")
BAT_VOLTAGE=$(read_file "$BAT_PATH/voltage_now" "0")
BAT_VOLTAGE=$((BAT_VOLTAGE / 1000))  # microvolts → millivolts
BAT_CURRENT=$(read_file "$BAT_PATH/current_now" "0")
BAT_CURRENT=$((BAT_CURRENT / 1000))  # microamps → milliamps
BAT_STATUS=$(read_file "$BAT_PATH/status" "Unknown")
BAT_HEALTH=$(read_file "$BAT_PATH/health" "Unknown")

# ── CPU ─────────────────────────────────────────────────
CPU_TEMP_RAW=$(read_file "/sys/class/thermal/thermal_zone0/temp" "0")
CPU_TEMP_INT=$((CPU_TEMP_RAW / 1000))
CPU_TEMP_FRAC=$(( (CPU_TEMP_RAW % 1000) / 100 ))

LOADAVG=$(cat /proc/loadavg 2>/dev/null)
LOAD1=$(echo "$LOADAVG" | awk '{print $1}')
LOAD5=$(echo "$LOADAVG" | awk '{print $2}')
LOAD15=$(echo "$LOADAVG" | awk '{print $3}')

CPU_CORES=$(nproc 2>/dev/null || echo "4")

# ── Memory ──────────────────────────────────────────────
MEM_TOTAL=$(awk '/^MemTotal:/ {print int($2/1024)}' /proc/meminfo)
MEM_AVAILABLE=$(awk '/^MemAvailable:/ {print int($2/1024)}' /proc/meminfo)
MEM_USED=$((MEM_TOTAL - MEM_AVAILABLE))

# ── Disk ────────────────────────────────────────────────
DISK_LINE=$(df -BG / 2>/dev/null | tail -1)
DISK_TOTAL=$(echo "$DISK_LINE" | awk '{gsub("G",""); print $2}')
DISK_USED=$(echo "$DISK_LINE" | awk '{gsub("G",""); print $3}')
DISK_AVAIL=$(echo "$DISK_LINE" | awk '{gsub("G",""); print $4}')
DISK_PCT=$(echo "$DISK_LINE" | awk '{gsub("%",""); print $5}')

# ── Network ─────────────────────────────────────────────
# Report the actual default-route interface, not a hardcoded wlan0.
# Handles ethernet (eth0) primary, either wifi radio (wlan0/wlan1), or
# no-internet states (AP-only fallback).
PRIMARY_IFACE=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}' || true)
if [ -z "$PRIMARY_IFACE" ] || [[ "$PRIMARY_IFACE" == tail* ]]; then
    # No internet route, or default goes via tailscale (pick the underlying iface
    # behind tailscale by inspecting the tailscale-up interface — fall back to wlan0).
    PRIMARY_IFACE=$(ip -o link show up 2>/dev/null \
        | awk -F': ' '{print $2}' \
        | grep -E '^(eth|wlan)' | head -1 || echo "wlan0")
fi

WIFI_IP=$(ip -4 addr show "$PRIMARY_IFACE" 2>/dev/null | grep -oP 'inet \K[0-9.]+' | head -1 || echo "none")

if [[ "$PRIMARY_IFACE" == eth* ]]; then
    NETWORK_KIND="ethernet"
    WIFI_SSID="Ethernet"
    LINK_SPEED=$(ethtool "$PRIMARY_IFACE" 2>/dev/null | grep -oP 'Speed:\s+\K[0-9]+' || echo "0")
    WIFI_SIGNAL=0
    WIFI_QUALITY=100
    WIFI_BITRATE="$LINK_SPEED"
elif [[ "$PRIMARY_IFACE" == wlan* ]]; then
    NETWORK_KIND="wifi"
    WIFI_RAW=$(iwconfig "$PRIMARY_IFACE" 2>/dev/null || true)
    WIFI_SSID=$(echo "$WIFI_RAW" | grep -oP 'ESSID:"\K[^"]+' || echo "disconnected")
    WIFI_SIGNAL=$(echo "$WIFI_RAW" | grep -oP 'Signal level=\K-?[0-9]+' || echo "0")
    WIFI_QUALITY_RAW=$(echo "$WIFI_RAW" | grep -oP 'Link Quality=\K[0-9]+/[0-9]+' || echo "0/70")
    WIFI_QUALITY_NUM=$(echo "$WIFI_QUALITY_RAW" | cut -d/ -f1)
    WIFI_QUALITY_DEN=$(echo "$WIFI_QUALITY_RAW" | cut -d/ -f2)
    if [ "$WIFI_QUALITY_DEN" -gt 0 ] 2>/dev/null; then
        WIFI_QUALITY=$((WIFI_QUALITY_NUM * 100 / WIFI_QUALITY_DEN))
    else
        WIFI_QUALITY=0
    fi
    WIFI_BITRATE=$(echo "$WIFI_RAW" | grep -oP 'Bit Rate=\K[0-9.]+' || echo "0")
else
    NETWORK_KIND="unknown"
    WIFI_SSID="disconnected"
    WIFI_SIGNAL=0
    WIFI_QUALITY=0
    WIFI_BITRATE=0
fi

# ── Screen ──────────────────────────────────────────────
BL_PATH=$(ls -d /sys/class/backlight/*/brightness 2>/dev/null | head -1)
if [ -n "$BL_PATH" ]; then
    BL_DIR=$(dirname "$BL_PATH")
    SCREEN_BRIGHTNESS=$(read_file "$BL_PATH" "0")
    SCREEN_MAX=$(read_file "$BL_DIR/max_brightness" "255")
else
    SCREEN_BRIGHTNESS=0
    SCREEN_MAX=255
fi

# ── System ──────────────────────────────────────────────
HOSTNAME=$(hostname)
KERNEL=$(uname -r)
UPTIME_RAW=$(awk '{print int($1)}' /proc/uptime)
UPTIME_DAYS=$((UPTIME_RAW / 86400))
UPTIME_HOURS=$(( (UPTIME_RAW % 86400) / 3600 ))
UPTIME_MINS=$(( (UPTIME_RAW % 3600) / 60 ))
if [ "$UPTIME_DAYS" -gt 0 ]; then
    UPTIME_STR="${UPTIME_DAYS}d ${UPTIME_HOURS}h ${UPTIME_MINS}m"
elif [ "$UPTIME_HOURS" -gt 0 ]; then
    UPTIME_STR="${UPTIME_HOURS}h ${UPTIME_MINS}m"
else
    UPTIME_STR="${UPTIME_MINS}m"
fi

# ── AIO Board ───────────────────────────────────────────
# SDR (RTL2838)
if lsusb 2>/dev/null | grep -q '0bda:2838'; then
    AIO_SDR_DETECTED=true
    AIO_SDR_CHIP="RTL2838"
else
    AIO_SDR_DETECTED=false
    AIO_SDR_CHIP=""
fi

# LoRa (SX1262 on SPI)
if [ -e /dev/spidev4.0 ]; then
    AIO_LORA_DETECTED=true
    AIO_LORA_CHIP="SX1262"
else
    AIO_LORA_DETECTED=false
    AIO_LORA_CHIP=""
fi

# GPS
AIO_GPS_DETECTED=false
AIO_GPS_FIX=false
if [ -c /dev/ttyS0 ]; then
    GPS_DATA=$(timeout 3 cat /dev/ttyS0 2>/dev/null || true)
    if echo "$GPS_DATA" | grep -q '^\$G'; then
        AIO_GPS_DETECTED=true
        if echo "$GPS_DATA" | grep -qP '\$G[NP]GGA,[^,]+,[0-9]+\.[0-9]+,[NS],[0-9]+\.[0-9]+,[EW]'; then
            AIO_GPS_FIX=true
        fi
    fi
fi

# ESP32 Marauder (CP210x on internal USB-C)
AIO_ESP32_DETECTED=false
AIO_ESP32_FW=""
if [ -e /dev/esp32 ]; then
    AIO_ESP32_DETECTED=true
    AIO_ESP32_FW=$(timeout 5 bash "$HOME/scripts/esp32-marauder.sh" version 2>/dev/null || echo "unknown")
fi

# RTC (PCF85063A at 0x51 — check /sys/class/rtc, fallback to i2cdetect)
AIO_RTC_DETECTED=false
AIO_RTC_SYNCED=false
AIO_RTC_TIME=""
if [ -d /sys/class/rtc/rtc0 ]; then
    AIO_RTC_DETECTED=true
    AIO_RTC_TIME=$(sudo hwclock -r 2>/dev/null | head -1)
    if [ -n "$AIO_RTC_TIME" ]; then
        AIO_RTC_SYNCED=true
    fi
fi

# ── Webdash ────────────────────────────────────────────
WEBDASH_RUNNING=false
WEBDASH_PORT=8080
if systemctl --user is-active --quiet webdash.service 2>/dev/null; then
    WEBDASH_RUNNING=true
    WEBDASH_PORT=$(systemctl --user show webdash.service -p Environment 2>/dev/null \
        | grep -oP 'WEBDASH_PORT=\K[0-9]+' || echo "8080")
fi

# ── WiFi Fallback ──────────────────────────────────────
WIFI_FALLBACK_ENABLED=false
WIFI_FALLBACK_AP="uConsole"
FALLBACK_CONF="${HOME}/.config/uconsole/wifi-fallback.conf"
if [ -f "$FALLBACK_CONF" ] && grep -q '^enabled=1' "$FALLBACK_CONF" 2>/dev/null; then
    WIFI_FALLBACK_ENABLED=true
    WIFI_FALLBACK_AP=$(grep -oP '^ap_name=\K.+' "$FALLBACK_CONF" 2>/dev/null || echo "uConsole")
fi

# ── Timestamp ───────────────────────────────────────────
COLLECTED_AT=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# ── Build JSON ──────────────────────────────────────────
JSON=$(cat <<ENDJSON
{
  "hostname": "$(json_escape "$HOSTNAME")",
  "uptime": "$(json_escape "$UPTIME_STR")",
  "uptimeSeconds": $UPTIME_RAW,
  "kernel": "$(json_escape "$KERNEL")",
  "battery": {
    "capacity": $BAT_CAPACITY,
    "voltage": $BAT_VOLTAGE,
    "current": $BAT_CURRENT,
    "status": "$(json_escape "$BAT_STATUS")",
    "health": "$(json_escape "$BAT_HEALTH")"
  },
  "cpu": {
    "tempC": ${CPU_TEMP_INT}.${CPU_TEMP_FRAC},
    "loadAvg": [$LOAD1, $LOAD5, $LOAD15],
    "cores": $CPU_CORES
  },
  "memory": {
    "totalMB": $MEM_TOTAL,
    "usedMB": $MEM_USED,
    "availableMB": $MEM_AVAILABLE
  },
  "disk": {
    "totalGB": $DISK_TOTAL,
    "usedGB": $DISK_USED,
    "availableGB": $DISK_AVAIL,
    "usedPercent": $DISK_PCT
  },
  "wifi": {
    "ssid": "$(json_escape "$WIFI_SSID")",
    "signalDBm": $WIFI_SIGNAL,
    "quality": $WIFI_QUALITY,
    "bitrateMbps": $WIFI_BITRATE,
    "ip": "$(json_escape "$WIFI_IP")",
    "iface": "$(json_escape "$PRIMARY_IFACE")",
    "kind": "$(json_escape "$NETWORK_KIND")"
  },
  "aio": {
    "sdr": { "detected": $AIO_SDR_DETECTED, "chip": "$(json_escape "$AIO_SDR_CHIP")" },
    "lora": { "detected": $AIO_LORA_DETECTED, "chip": "$(json_escape "$AIO_LORA_CHIP")" },
    "gps": { "detected": $AIO_GPS_DETECTED, "hasFix": $AIO_GPS_FIX },
    "esp32": { "detected": $AIO_ESP32_DETECTED, "firmware": "$(json_escape "$AIO_ESP32_FW")" },
    "rtc": { "detected": $AIO_RTC_DETECTED, "synced": $AIO_RTC_SYNCED, "time": "$(json_escape "$AIO_RTC_TIME")" }
  },
  "screen": {
    "brightness": $SCREEN_BRIGHTNESS,
    "maxBrightness": $SCREEN_MAX
  },
  "webdash": {
    "running": $WEBDASH_RUNNING,
    "port": $WEBDASH_PORT
  },
  "wifiFallback": {
    "enabled": $WIFI_FALLBACK_ENABLED,
    "apName": "$(json_escape "$WIFI_FALLBACK_AP")"
  },
  "collectedAt": "$COLLECTED_AT"
}
ENDJSON
)

# ── Push to API ─────────────────────────────────────────
COMPACT_JSON=$(printf '%s' "$JSON" | tr -d '\n' | tr -s ' ')

HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' \
    --connect-timeout 10 --max-time 30 \
    -X POST "${DEVICE_API_URL}" \
    -H "Authorization: Bearer ${DEVICE_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "$COMPACT_JSON")

if [ "$HTTP_CODE" = "200" ]; then
    echo "[$(date -Iseconds)] Status pushed (HTTP $HTTP_CODE)"
elif [ "$HTTP_CODE" = "401" ]; then
    echo "[$(date -Iseconds)] ERROR: Invalid device token (HTTP 401). Regenerate at https://uconsole.cloud" >&2
    exit 1
else
    echo "[$(date -Iseconds)] ERROR: Push failed (HTTP $HTTP_CODE)" >&2
    exit 1
fi
